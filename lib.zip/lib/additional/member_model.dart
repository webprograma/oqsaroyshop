class Member {
  String uid = "";
  String name = "";
  String email = "";

  String device_id = "";
  String device_type = "";
  String device_token = "";

  Member(this.name, this.email);

  Member.fromJson(Map<String, dynamic> json)
      : name = json['name'],
        uid = json['uid'],
        device_id = json['device_id'],
        device_type = json['device_type'],
        device_token = json['device_token'],
        email = json['email'];

  Map<String, dynamic> toJson() => {
        'name': name,
        'uid': uid,
        'device_id': device_id,
        'device_type': device_type,
        'device_token': device_token,
        'email': email,
      };
}
