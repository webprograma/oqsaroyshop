import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:instaclone/pages/vital_pages/myfavouritePage.dart';
import 'package:instaclone/pages/vital_pages/mymainpage.dart';
import 'package:instaclone/pages/vital_pages/myprofilepage.dart';
import 'package:instaclone/pages/vital_pages/mysearchpage.dart';
import 'package:instaclone/pages/vital_pages/upload_page.dart';

class HomePage extends StatefulWidget {
  static final String id = 'home';

  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late PageController pageController; // Declare the pageController as late

  int currentTab = 0;

  @override
  void initState() {
    super.initState();
    pageController = PageController();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: PageView(
        controller: pageController,
        onPageChanged: (int index) {
          setState(() {
            currentTab = index;
          });
        },
        children: [
          MyMainPage(
            pageController: pageController,
          ),
          MySearchPage(),
          UploadPage(
            pageController: pageController,
          ),
          MyFavouritePage(),
          MyProfilePage(),
        ],
      ),
      bottomNavigationBar: CupertinoTabBar(
        onTap: (int index) {
          setState(() {
            currentTab = index;
            pageController.animateToPage(index,
                duration: Duration(milliseconds: 200), curve: Curves.easeIn);
          });
        },
        items: [
          BottomNavigationBarItem(
            icon: Icon(
              Icons.home,
              size: 32,
            ),
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.search,
              size: 32,
            ),
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.add,
              size: 32,
            ),
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.favorite,
              size: 32,
            ),
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.account_circle,
              size: 32,
            ),
          ),
        ],
        currentIndex: currentTab,
        activeColor: Color.fromRGBO(193, 53, 132, 1),
      ),
    );
  }
}
