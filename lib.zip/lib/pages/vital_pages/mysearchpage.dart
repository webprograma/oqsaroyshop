import 'package:flutter/material.dart';
import 'package:instaclone/additional/member_model.dart';

class MySearchPage extends StatefulWidget {
  const MySearchPage({super.key});

  @override
  State<MySearchPage> createState() => _MySearchPageState();
}

class _MySearchPageState extends State<MySearchPage> {
  List<Member> items = [];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    items.add(Member('Sardor', 'sardor@gmail.com'));
    items.add(Member('Jasur', 'jasur@gmail.com'));
    items.add(Member('Doniyor', 'doniyor@gmail.com'));
    items.add(Member('Olim', 'olim@gmail.com'));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(
            'Search',
            style: TextStyle(
                color: Color.fromRGBO(193, 53, 132, 1),
                fontSize: 35,
                fontFamily: "Billabong"),
          ),
        ),
        body: Stack(
          children: [
            Container(
              padding: EdgeInsets.only(left: 20, right: 20),
              child: Column(
                children: [
                  Container(
                    height: 50,
                    decoration: BoxDecoration(
                        color: Colors.grey.shade300,
                        borderRadius: BorderRadius.circular(10)),
                    padding: EdgeInsets.all(1),
                    child: Row(
                      children: [
                        SizedBox(
                          width: 10,
                        ),
                        Icon(Icons.search),
                        SizedBox(
                          width: 10,
                        ),
                        Expanded(
                            child: TextField(
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: 'Search',
                          ),
                        ))
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Expanded(
                    child: ListView.builder(
                      itemCount: items.length,
                      itemBuilder: (context, index) {
                        return itemOfPost(items[index]);
                      },
                    ),
                  )
                ],
              ),
            ),
          ],
        ));
  }

  Widget itemOfPost(Member member) {
    return Container(
        child: Column(
      children: [
        Column(
          children: [
            SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Container(
                      height: 50,
                      width: 50,
                      decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(width: 1.5, color: Colors.pink),
                          image: DecorationImage(
                              image: AssetImage('assets/images/user.jpg'))),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          member.name,
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        Text(member.email),
                      ],
                    )
                  ],
                ),
                InkWell(
                  child: Container(
                      width: 70,
                      height: 30,
                      decoration: BoxDecoration(
                          color: Colors.blue,
                          borderRadius: BorderRadius.circular(6)),
                      child: Center(
                        child: Text(
                          'Follow',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.bold),
                        ),
                      )),
                )
              ],
            ),
          ],
        )
      ],
    ));
  }
}
