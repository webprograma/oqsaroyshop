import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:instaclone/additional/model.dart';

class MyMainPage extends StatefulWidget {
  final PageController? pageController;
  const MyMainPage({super.key, this.pageController});

  @override
  State<MyMainPage> createState() => _MyMainPageState();
}

class _MyMainPageState extends State<MyMainPage> {
  bool isLoading = false;
  List<Post> items = [];
  String img_1 =
      'https://images.unsplash.com/photo-1707343844436-37580f155ed2?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDF8MHxlZGl0b3JpYWwtZmVlZHwxfHx8ZW58MHx8fHx8';
  String img_2 =
      'https://plus.unsplash.com/premium_photo-1710523260461-c7c7f9ab7226?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxlZGl0b3JpYWwtZmVlZHwyfHx8ZW58MHx8fHx8';
  String img_3 =
      'https://images.unsplash.com/photo-1710390916960-3047fcdf561e?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxlZGl0b3JpYWwtZmVlZHw1fHx8ZW58MHx8fHx8';

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    items.add(Post(img_1, 'This is our first post'));
    items.add(Post(img_2, 'This is our second post'));
    items.add(Post(img_3, 'This is our third post'));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Instagram',
          style: TextStyle(
              color: Color.fromRGBO(193, 53, 132, 1),
              fontSize: 35,
              fontFamily: "Billabong"),
        ),
        actions: [
          IconButton(
              onPressed: () {
                widget.pageController!.animateToPage(2,
                    duration: Duration(microseconds: 200),
                    curve: Curves.easeIn);
              },
              icon: Icon(
                Icons.upload,
                color: Color.fromRGBO(193, 53, 132, 1),
                size: 25,
              ))
        ],
      ),
      body: Stack(
        children: [
          ListView.builder(
            itemBuilder: (context, index) {
              return itemOfPost(items[index]);
            },
            itemCount: items.length,
          ),
          isLoading
              ? Center(
                  child: CircularProgressIndicator(),
                )
              : SizedBox()
        ],
      ),
    );
  }

  Widget itemOfPost(Post post) {
    return Container(
      color: Colors.white,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Divider(),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Container(
                      height: 50,
                      width: 50,
                      decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          image: DecorationImage(
                              image: AssetImage('assets/images/user.jpg'))),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Abdurahmon Mahmudov',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        Text('2024-21-3  12:25'),
                      ],
                    )
                  ],
                ),
                IconButton(onPressed: () {}, icon: Icon(Icons.more_horiz))
              ],
            ),
          ),
          SizedBox(
            height: 7,
          ),
          CachedNetworkImage(
            fit: BoxFit.cover,
            width: double.infinity,
            height: MediaQuery.of(context).size.width,
            imageUrl: post.img_post,
            placeholder: (context, url) => CircularProgressIndicator(),
            errorWidget: (context, url, error) => Icon(Icons.error),
          ),
          SizedBox(
            height: 5,
          ),
          Row(
            children: [
              IconButton(
                  onPressed: () {},
                  icon: Icon(
                    Icons.favorite,
                    size: 23,
                    color: Colors.pink,
                  )),
              SizedBox(
                width: 10,
              ),
              IconButton(
                  onPressed: () {},
                  icon: Icon(
                    Icons.comment_outlined,
                    size: 23,
                    color: Colors.pink,
                  )),
              SizedBox(
                width: 10,
              ),
              IconButton(
                  onPressed: () {},
                  icon: Icon(
                    Icons.share,
                    size: 23,
                    color: Colors.pink,
                  )),
            ],
          ),
          Container(
            margin: EdgeInsets.only(left: 10),
            child: Text(
              post.caption,
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          )
        ],
      ),
    );
  }
}
