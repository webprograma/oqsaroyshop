import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:instaclone/additional/model.dart';
import 'package:instaclone/servise/firebase_servise.dart';

class MyProfilePage extends StatefulWidget {
  const MyProfilePage({super.key});

  @override
  State<MyProfilePage> createState() => _MyProfilePageState();
}

class _MyProfilePageState extends State<MyProfilePage> {
  bool isLoading = false;
  List<Post> items = [];
  String img_1 =
      'https://images.unsplash.com/photo-1707343844436-37580f155ed2?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDF8MHxlZGl0b3JpYWwtZmVlZHwxfHx8ZW58MHx8fHx8';
  String img_2 =
      'https://plus.unsplash.com/premium_photo-1710523260461-c7c7f9ab7226?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxlZGl0b3JpYWwtZmVlZHwyfHx8ZW58MHx8fHx8';
  String img_3 =
      'https://images.unsplash.com/photo-1710390916960-3047fcdf561e?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxlZGl0b3JpYWwtZmVlZHw1fHx8ZW58MHx8fHx8';
  bool gridSelected = false;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    items.add(Post(img_1, 'This is our first post'));
    items.add(Post(img_2, 'This is our second post'));
    items.add(Post(img_3, 'This is our third post'));
  }

  _imgFromGallery() async {
    XFile? image =
        await picker.pickImage(source: ImageSource.gallery, imageQuality: 50);
    setState(() {
      _image = File(image!.path);
    });
  }

  ImagePicker picker = ImagePicker();
  File? _image;
  _imgFromCamera() async {
    XFile? image =
        await picker.pickImage(source: ImageSource.camera, imageQuality: 50);
    setState(() {
      _image = File(image!.path);
    });
  }

  void showPicker(context) {
    showModalBottomSheet(
        context: context,
        builder: (BuildContext context) {
          return SafeArea(
              child: Container(
            child: Wrap(
              children: [
                ListTile(
                  leading: new Icon(Icons.photo_library),
                  title: new Text('Gallery'),
                  onTap: () {
                    _imgFromGallery();
                    Navigator.pop(context);
                  },
                ),
                ListTile(
                  leading: new Icon(Icons.photo_camera),
                  title: new Text('Camera'),
                  onTap: () {
                    _imgFromCamera();
                    Navigator.pop(context);
                  },
                ),
              ],
            ),
          ));
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(
            'Profile',
            style: TextStyle(
                color: Color.fromRGBO(193, 53, 132, 1),
                fontSize: 35,
                fontFamily: "Billabong"),
          ),
          actions: [
            IconButton(
                onPressed: () {
                  FireBaseService.signOut(context);
                },
                icon: Icon(
                  Icons.logout,
                  color: Color.fromRGBO(193, 53, 132, 1),
                ))
          ],
        ),
        body: Container(
          width: double.infinity,
          child: Column(children: [
            InkWell(
              onTap: () {
                showPicker(context);
              },
              child: Stack(
                children: [
                  Container(
                    padding: EdgeInsets.all(2),
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          width: 1.5,
                          color: Color.fromRGBO(193, 53, 132, 1),
                        )),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(35),
                      child: _image == null
                          ? Image(
                              image: AssetImage('assets/images/user.jpg'),
                              height: 70,
                              width: 70,
                              fit: BoxFit.cover,
                            )
                          : Image.file(
                              _image!,
                              height: 70,
                              width: 70,
                              fit: BoxFit.cover,
                            ),
                    ),
                  )
                ],
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Text(
              'Abdurahmon',
              style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
            ),
            Text('abdurahmonmahmudov@gmail.com'),
            SizedBox(
              height: 10,
            ),
            Container(
                padding: EdgeInsets.all(10),
                height: 80,
                child: Row(
                  children: [
                    Expanded(
                      child: Container(
                        child: Center(
                          child: Column(
                            children: [
                              Text(
                                '${items.length}',
                                style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold),
                              ),
                              Text(
                                'Posts',
                                style: TextStyle(
                                    color: Colors.grey.shade700, fontSize: 16),
                              ),
                            ],
                          ),
                        ),
                      ),
                      flex: 1,
                    ),
                    Expanded(
                      child: Container(
                        child: Center(
                          child: Column(
                            children: [
                              Text(
                                '800M',
                                style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold),
                              ),
                              Text(
                                'Followers',
                                style: TextStyle(
                                    color: Colors.grey.shade700, fontSize: 16),
                              ),
                            ],
                          ),
                        ),
                      ),
                      flex: 1,
                    ),
                    Expanded(
                      child: Container(
                        child: Center(
                          child: Column(
                            children: [
                              Text(
                                '1',
                                style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold),
                              ),
                              Text(
                                'Following',
                                style: TextStyle(
                                    color: Colors.grey.shade700, fontSize: 16),
                              ),
                            ],
                          ),
                        ),
                      ),
                      flex: 1,
                    ),
                  ],
                )),
            Container(
              child: Row(
                children: [
                  Expanded(
                      child: IconButton(
                          onPressed: () {
                            setState(() {
                              gridSelected = false;
                            });
                          },
                          icon: Icon(Icons.list_alt))),
                  Expanded(
                      child: IconButton(
                          onPressed: () {
                            setState(() {
                              gridSelected = true;
                            });
                          },
                          icon: Icon(Icons.grid_view))),
                ],
              ),
            ),
            Expanded(
                child: GridView.builder(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: gridSelected == false ? 2 : 1),
              itemBuilder: (context, index) {
                return gridSelected == false
                    ? itemOfPost1(items[index])
                    : itemOfPost2(items[index]);
              },
              itemCount: items.length,
            ))
          ]),
        ));
  }

  Widget itemOfPost1(Post post) {
    return Container(
      margin: EdgeInsets.all(5),
      child: Column(
        children: [
          Expanded(
            child: CachedNetworkImage(
              imageUrl: post.img_post,
              width: double.infinity,
              height: 170,
              placeholder: (context, url) => Icon(Icons.error),
              fit: BoxFit.cover,
            ),
          ),
          SizedBox(
            height: 3,
          ),
          Text(
            post.caption,
            style: TextStyle(color: Colors.black87),
            maxLines: 2,
          )
        ],
      ),
    );
  }

  Widget itemOfPost2(Post post) {
    return Container(
      color: Colors.white,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Divider(),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Container(
                      height: 50,
                      width: 50,
                      decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          image: DecorationImage(
                              image: AssetImage('assets/images/user.jpg'))),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Abdurahmon Mahmudov',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        Text('2024-21-3  12:25'),
                      ],
                    )
                  ],
                ),
                IconButton(onPressed: () {}, icon: Icon(Icons.more_horiz))
              ],
            ),
          ),
          SizedBox(
            height: 7,
          ),
          CachedNetworkImage(
            fit: BoxFit.cover,
            width: double.infinity,
            height: 240,
            imageUrl: post.img_post,
            placeholder: (context, url) => CircularProgressIndicator(),
            errorWidget: (context, url, error) => Icon(Icons.error),
          ),
          SizedBox(
            height: 5,
          ),
          Row(
            children: [
              IconButton(
                  onPressed: () {},
                  icon: Icon(
                    Icons.favorite,
                    size: 23,
                    color: Colors.pink,
                  )),
              SizedBox(
                width: 10,
              ),
              IconButton(
                  onPressed: () {},
                  icon: Icon(
                    Icons.comment_outlined,
                    size: 23,
                    color: Colors.pink,
                  )),
              SizedBox(
                width: 10,
              ),
              IconButton(
                  onPressed: () {},
                  icon: Icon(
                    Icons.share,
                    size: 23,
                    color: Colors.pink,
                  )),
            ],
          ),
          Container(
            margin: EdgeInsets.only(left: 10),
            child: Text(
              post.caption,
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          )
        ],
      ),
    );
  }
}
