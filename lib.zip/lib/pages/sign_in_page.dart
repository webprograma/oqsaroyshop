import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:instaclone/pages/home_page.dart';
import 'package:instaclone/pages/sign_up_page.dart';
import 'package:instaclone/pages/vital_pages/upload_page.dart';
import 'package:instaclone/servise/firebase_servise.dart';

class SignInPage extends StatefulWidget {
  static final String id = '2';
  const SignInPage({super.key});

  @override
  State<SignInPage> createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  var emailController = TextEditingController();
  var passwordController = TextEditingController();
  _doSignIn() {
    String email = emailController.text.toString().trim();
    String password = passwordController.text.toString().trim();

    if (email.isEmpty || password.isEmpty) return;

    FireBaseService.signInUser(email, password).then((User? firebaseUser) {
      if (firebaseUser != null) {
        responseSignIn(firebaseUser);
      } else {
        // Handle sign-in failure
        // Show an error message or perform other actions as needed
        print('Sign-in failed');
      }
    });
  }

  void responseSignIn(User firebaseUser) {
    Navigator.pushReplacementNamed(context, HomePage.id);
  }

  callNextSignUp() {
    Navigator.pushReplacementNamed(context, SignUpPage.id);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: EdgeInsets.all(12),
        decoration: BoxDecoration(
            gradient: LinearGradient(colors: [
          Color.fromRGBO(245, 96, 64, 1),
          Color.fromRGBO(247, 119, 55, 1),
        ])),
        child: Stack(
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                //email
                Container(
                  height: 50,
                  padding: EdgeInsets.only(left: 10, right: 10),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(7),
                      color: Colors.white54.withOpacity(0.2)),
                  child: TextField(
                    controller: emailController,
                    style: TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                        hintText: "Email",
                        border: InputBorder.none,
                        hintStyle:
                            TextStyle(fontSize: 17, color: Colors.white54)),
                  ),
                ),

                SizedBox(
                  height: 12,
                ),
                //password
                Container(
                  height: 50,
                  padding: EdgeInsets.only(left: 10, right: 10),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(7),
                      color: Colors.white54.withOpacity(0.2)),
                  child: TextField(
                    controller: passwordController,
                    obscureText: true,
                    style: TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                        hintText: "Password",
                        border: InputBorder.none,
                        hintStyle:
                            TextStyle(fontSize: 17, color: Colors.white54)),
                  ),
                ),

                SizedBox(
                  height: 12,
                ),
                //button
                InkWell(
                  onTap: () {
                    _doSignIn();
                  },
                  child: Container(
                    height: 50,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(7),
                        color: Colors.white54.withOpacity(0.2)),
                    child: Center(
                      child: Text(
                        "Sign In",
                        style: TextStyle(color: Colors.white54, fontSize: 17),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 12,
                ),
                //text

                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      "Do you have not an account : ",
                      style: TextStyle(color: Colors.white54, fontSize: 15),
                    ),
                    TextButton(
                        onPressed: callNextSignUp,
                        child: Text(
                          "Sign Up",
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 16),
                        )),
                  ],
                ),
              ],
            )
          ],
        ),
      ),
    );
    ;
  }
}
